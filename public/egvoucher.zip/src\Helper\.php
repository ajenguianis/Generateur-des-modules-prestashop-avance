<?php

declare(strict_types=1);

namespace EvoGroup\Module\Egvoucher\;

class 
{

}