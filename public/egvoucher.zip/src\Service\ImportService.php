<?php

declare(strict_types=1);

namespace EvoGroup\Module\Egvoucher\ImportService;

use Psr\Log\LoggerInterface;

/**
 * Class ImportService
 */
class ImportService
{
    /**
     * @var LoggerInterface
     */
    private $_logger;
    public function __construct(LoggerInterface $logger)
    {
        $this->_logger = $logger;
    }
}